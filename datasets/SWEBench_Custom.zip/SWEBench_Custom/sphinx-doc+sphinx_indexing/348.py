exclude_patterns = ['_build']

latex_elements = {
    'maxlistdepth': '10',
}
