class Bar:
    """Bar class"""
    pass


def foo():
    """Foo function"""
    pass
