def private_function(name):
    """private_function is a docstring().

    :meta private:
    """
