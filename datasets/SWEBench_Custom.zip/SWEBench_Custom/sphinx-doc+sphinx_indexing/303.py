extensions = ['sphinx.ext.viewcode']
exclude_patterns = ['_build']
viewcode_follow_imported_members = False
