from .submodule import func1, Class1  # NOQA
