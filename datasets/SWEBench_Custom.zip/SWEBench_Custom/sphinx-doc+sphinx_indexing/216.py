latex_documents = [
    ('index', 'test.tex', 'The basic Sphinx documentation for testing', 'Sphinx', 'report')
]
