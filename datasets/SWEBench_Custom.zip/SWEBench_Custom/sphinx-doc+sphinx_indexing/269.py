extensions = ['sphinx.ext.autosectionlabel']
autosectionlabel_prefix_document = True
