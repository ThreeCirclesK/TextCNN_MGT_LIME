from typing import Annotated


def hello(name: Annotated[str, "attribute"]) -> None:
    """docstring"""
    pass
