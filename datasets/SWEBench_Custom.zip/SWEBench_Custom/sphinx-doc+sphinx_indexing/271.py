from .autosummary_dummy_module import Bar, foo
