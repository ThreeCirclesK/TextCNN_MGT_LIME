master_doc = 'links'
source_suffix = '.txt'
exclude_patterns = ['_build']
linkcheck_anchors = True
